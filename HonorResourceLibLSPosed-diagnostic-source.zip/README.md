# HonorResourceLibLSPosed (诊断骨架)

## 当前状态
这是一个 **诊断骨架**，不是已经实现资源库恢复的成品。它只在荣耀桌面包名 `com.hihonor.android.launcher` 加载时写入 Xposed 日志。它不会更改桌面设置、不会创建假入口，也不会宣称恢复成功。

原因：MagicOS 9.0 的具体机型、桌面 APK 版本和内部实现尚未提供。荣耀官方说明资源库需要标准风格及桌面设置中的资源库开关；如果开关消失，必须先确认该版本是否仍含有资源库 Activity、相关设置项和入口逻辑。不能安全地猜内部类名/偏好键。

## GitHub Actions 在线编译
1. 在 GitHub 新建一个空仓库。
2. 上传本项目全部文件（保留 `.github/workflows/build.yml`）。
3. 打开仓库 `Actions`，选择 `Build diagnostic APK`，点 `Run workflow`。
4. 构建成功后，在运行记录底部的 Artifacts 下载 `HonorResourceLib-diagnostic-debug`。
5. 此 APK 仅用于验证模块是否能编译/被 LSPosed 加载，不会恢复资源库入口。

## LSPosed 使用/日志
- 安装 APK。
- 在 LSPosed 中启用模块，并把作用域仅勾选荣耀桌面（如果包名不同，以设备实际桌面包名为准）。
- 重启或强制停止后重新启动荣耀桌面。
- 使用 LSPosed 日志查看 `HonorResourceLib`。
- 不要把诊断版当成恢复版长期使用。

## 下一步需要的设备信息
在电脑/ADB 环境或能读取系统应用信息的工具中获取：
- 荣耀桌面包名及版本号；
- 系统版本完整构建号；
- 桌面 APK（通常为系统应用，导出时注意不要修改原文件）。

也可以先在手机“设置 > 应用 > 应用管理 > 荣耀桌面”查看版本号，并发截图。若能提供对应桌面 APK 或其反编译输出（Manifest、Activity 列表、资源库相关字符串），再实现针对实际入口/开关的 Hook。

## Build details
- Legacy Xposed API 82; Java 17; Android Gradle Plugin 8.5.2; compileSdk 35.
- GitHub-hosted runner downloads dependencies from Maven Central/Google repositories.
