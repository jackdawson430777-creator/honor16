package dev.dawson.honorresourcelib;

import android.app.Application;
import android.content.Context;
import android.content.res.Resources;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.Locale;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Diagnostic-only legacy Xposed entry point.
 * It deliberately does not guess Honor's private preference keys or internal classes.
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "HonorResourceLib";
    private static final String TARGET = "com.hihonor.android.launcher";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET.equals(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": attached to package=" + lpparam.packageName
                + ", process=" + lpparam.processName);

        try {
            XposedBridge.hookAllMethods(Application.class, "attach", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Object arg = param.args != null && param.args.length > 0 ? param.args[0] : null;
                    if (!(arg instanceof Context)) return;
                    Context context = (Context) arg;
                    try {
                        Resources res = context.getResources();
                        int count = 0;
                        for (int id : getResourceIds(res)) {
                            try {
                                String name = res.getResourceEntryName(id);
                                String lower = name.toLowerCase(Locale.ROOT);
                                if (lower.contains("resource") || lower.contains("library")
                                        || lower.contains("drawer") || lower.contains("app_list")
                                        || lower.contains("category") || lower.contains("recommend")) {
                                    XposedBridge.log(TAG + ": resource candidate "
                                            + name + " = 0x" + Integer.toHexString(id));
                                    count++;
                                    if (count >= 300) break;
                                }
                            } catch (Throwable ignored) { }
                        }
                        XposedBridge.log(TAG + ": resource candidate count logged=" + count
                                + "; this is diagnostic only, not proof that a resource is the entry.");
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + ": resource scan failed: " + Log.getStackTraceString(t));
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook setup failed: " + Log.getStackTraceString(t));
        }
    }

    private static int[] getResourceIds(Resources resources) {
        // Android Resources does not expose a public enumeration API.
        // Use the APK's package resource table via the package's generated R class is
        // impossible without its private package-specific R class, so return empty here.
        // The hook still confirms module scope/attach. APK analysis is required for IDs.
        return new int[0];
    }
}
