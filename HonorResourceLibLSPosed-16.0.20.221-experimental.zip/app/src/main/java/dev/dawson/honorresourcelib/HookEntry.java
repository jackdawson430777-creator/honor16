package dev.dawson.honorresourcelib;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "HonorResourceLib";
    private static final String TARGET = "com.hihonor.android.launcher";

    /*
     * APK inspected: Honor launcher 16.0.20.221 (16020221).
     * The DEX contains the preference-like key "magic_library_enabled",
     * plus AppLibrary / DrawerLauncher / updateLibraryEnable symbols.
     * The preference key's exact read/write call site is not yet confirmed,
     * so this is an experimental probe, not a guaranteed fix.
     */
    private static final String LIBRARY_KEY = "magic_library_enabled";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET.equals(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": attached to Honor launcher "
                + lpparam.packageName + " process=" + lpparam.processName);

        try {
            XposedHelpers.findAndHookMethod(
                    "android.app.SharedPreferencesImpl",
                    lpparam.classLoader,
                    "getBoolean",
                    String.class,
                    boolean.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            Object key = param.args[0];
                            if (LIBRARY_KEY.equals(key)) {
                                param.setResult(Boolean.TRUE);
                                XposedBridge.log(TAG
                                        + ": forced SharedPreferences.getBoolean("
                                        + LIBRARY_KEY + ") = true");
                            }
                        }
                    });
            XposedBridge.log(TAG + ": installed getBoolean probe");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": could not hook SharedPreferencesImpl.getBoolean: "
                    + t);
        }
    }
}
