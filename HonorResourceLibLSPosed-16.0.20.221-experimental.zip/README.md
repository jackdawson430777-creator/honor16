# HonorResourceLibLSPosed — experimental hook

## What was found in the supplied APK
Target APK: `荣耀桌面-16.0.20.221-16020221.apk`.

DEX string inspection found these relevant symbols/strings:
- `magic_library_enabled`
- `updateLibraryEnable` / `updateLibraryEnableText`
- `AppLibrary`
- `DrawerLauncher` / `com.hihonor.android.launcher.drawer.DrawerLauncher`
- `launcher_resource_library`
- resource layouts such as `activity_resource_lib_setting.xml` and `preference_resource_lib_settings.xml`

This strongly suggests the APK still contains resource-library related code. It does **not** prove that `magic_library_enabled` is the exact controlling preference or that the library UI is enabled on the target device.

## Current experimental behavior
This module only targets `com.hihonor.android.launcher` and hooks `android.app.SharedPreferencesImpl.getBoolean(String, boolean)`. If the requested key is exactly `magic_library_enabled`, it returns `true`.

This is a narrow experimental test. It does not create a fake icon and does not directly hook internal `DrawerLauncher` methods. If the key is not used through this method, the hook will have no effect. No APK build or device test has been performed in this environment.

## GitHub Actions online build
1. Create an empty GitHub repository.
2. Upload all files from this ZIP, including `.github/workflows/build.yml`.
3. Open **Actions → Build diagnostic APK → Run workflow**.
4. Download the artifact `HonorResourceLib-diagnostic-debug` after a successful run.

The output APK is named `app-debug.apk`. It is an experimental LSPosed module, not a confirmed working release.

## Install and test
1. Install the APK.
2. Enable it in LSPosed and scope it only to the Honor launcher package.
3. Restart the launcher (or reboot).
4. Check LSPosed logs for `HonorResourceLib`.
5. If the entry does not return, send the LSPosed log and device's full MagicOS build number. Do not assume the key is correct from its name alone.

## Build
- Java 17
- Android Gradle Plugin 8.5.2
- compileSdk 35
- legacy Xposed API 82
